﻿using System;
namespace ConsoleApp5
{
     class Auto
    {
        public int Seats { get; set; }
        public Auto(int seats)
        {
            Seats = seats;
        }
    }
    class Truck : Auto
    {
        public decimal Capacity { get; set; }
        public Truck(int seats, decimal capacity) : base(seats) 
        {
            Seats = seats;
            Capacity = capacity;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Truck truck = new Truck(2, 1.1m);
            Console.WriteLine($"Грузовик с грузопоъемностью {truck.Capacity} тонн");
            Console.ReadKey();
        }
    }
}
//Эта программа выведет на консоль:Грузовик с грузопоъемностью 1.1 тонн
//Это происходит потому, что в классе Truck определен конструктор который принимает два аргумента: seats и capacity. В методе Main создается объект Truck с 2 сиденьями и грузоподъемностью 1.1 тонны. Затем в консоль выводится сообщение. Так как значение свойства Capacity было установлено в конструкторе Truck в 1.1, то и в консоль выводится "Грузовик с грузопоъемностью 1.1 тонн".