﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double x = 9;
        double firstValue, secondValue, result;
        firstValue = Math.Pow(x, 2);
        secondValue = Math.Pow(3, 3) * Math.Sqrt(x);
        result = 2 * firstValue - secondValue;
        Console.WriteLine("ответ= " + result);
        Console.ReadKey();
    }
}