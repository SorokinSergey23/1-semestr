﻿using System;
namespace Ser4
{
    class Program
    {
        static void Main(string[] args)
        {
            double x = 4;
            double otvet;
            otvet = 5 * Math.Pow(x, 2) - 12 * x + 4 / 6 - 15 * x;
            Console.WriteLine($"Ответ={otvet}");
            Console.ReadKey();
        }
    }
}