﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите первое число ");
        int c1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Введите второе число ");
        int c2 = Convert.ToInt32(Console.ReadLine());
        int max = Math.Max(c1, c2);
        Console.WriteLine("Наибольшее число " + max);
    }
}