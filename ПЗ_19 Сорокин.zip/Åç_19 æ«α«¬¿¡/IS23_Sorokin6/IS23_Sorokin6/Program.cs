﻿using System;
using System.Linq;
public class Point
{
    public double X { get; }
    public double Y { get; }
    public Point(double x, double y)
    {
        X = x;
        Y = y;
    }
    public double DistanceFromOrigin()
    {
        return Math.Sqrt(X * X + Y * Y);
    }
}
public class Program
{
    public static Point[] SortPoints(Point[] points)
    {
        return points.OrderBy(p => p.DistanceFromOrigin()).ToArray();
    }
    public static bool IsRegularPolygon(Point[] points)
    {
        if (points.Length < 3) return false;

        double sideLength = Distance(points[0], points[1]);
        for (int i = 1; i < points.Length; i++)
        {
            double currentSideLength = Distance(points[i], points[(i + 1) % points.Length]);
            if (Math.Abs(currentSideLength - sideLength) > 1e-9)
                return false;
        }
        return true;
    }
    public static double Distance(Point p1, Point p2)
    {
        return Math.Sqrt(Math.Pow(p1.X - p2.X, 2) + Math.Pow(p1.Y - p2.Y, 2));
    }
    static void Main(string[] args)
    {
        Console.WriteLine("Введите количество точек:");
        int n = int.Parse(Console.ReadLine());
        Point[] points = new Point[n];

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Введите координаты точки {i + 1} (x y):");
            var coordinates = Console.ReadLine().Split();
            double x = double.Parse(coordinates[0]);
            double y = double.Parse(coordinates[1]);
            points[i] = new Point(x, y);
        }
        Point[] sortedPoints = SortPoints(points);
        Console.WriteLine("Точки, отсортированные по удалению от центра:");
        foreach (var point in sortedPoints)
        {
            Console.WriteLine($"({point.X}, {point.Y})");
        }
        if (IsRegularPolygon(sortedPoints))
        {
            Console.WriteLine("Точки представляют вершины правильного многоугольника.");
            Console.WriteLine($"Количество вершин: {sortedPoints.Length}");
        }
        else
        {
            Console.WriteLine("Точки не представляют вершины правильного многоугольника.");
        }
    }
}