﻿using System;
using System.Collections.Generic;
namespace PairingPoints
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество точек (четное число, не более 20): ");
            int n = Convert.ToInt32(Console.ReadLine());
            if (n % 2 != 0 || n > 20)
            {
                Console.WriteLine("Ошибка: количество точек должно быть четным и не более 20.");
                return;
            }
            List<Point> points = new List<Point>();
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Введите координаты точки {i + 1} (x y): ");
                string[] input = Console.ReadLine().Split();
                double x = Convert.ToDouble(input[0]);
                double y = Convert.ToDouble(input[1]);
                points.Add(new Point(i + 1, x, y));
            }
            Console.WriteLine("\nНепересекающиеся отрезки:");
            for (int i = 0; i < n; i += 2)
            {
                Console.WriteLine($"Отрезок: {points[i].Index} ({points[i].X}, {points[i].Y}) - {points[i + 1].Index} ({points[i + 1].X}, {points[i + 1].Y})");
            }

            Console.ReadKey();
        }
    }
    class Point
    {
        public int Index { get; }
        public double X { get; }
        public double Y { get; }
        public Point(int index, double x, double y)
        {
            Index = index;
            X = x;
            Y = y;
        }
    }
}