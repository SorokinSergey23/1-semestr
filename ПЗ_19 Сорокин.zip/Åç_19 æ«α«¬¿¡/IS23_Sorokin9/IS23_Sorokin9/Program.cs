﻿using System;
using System.Collections.Generic;
using System.Linq;
class Point
{
    public int Index { get; set; }
    public double X { get; set; }
    public double Y { get; set; }
    public Point(int index, double x, double y)
    {
        Index = index;
        X = x;
        Y = y;
    }
    public double DistanceTo(Point other)
    {
        return Math.Sqrt(Math.Pow(X - other.X, 2) + Math.Pow(Y - other.Y, 2));
    }
}
class Program
{
    static void Main()
    {
        Console.Write("Введите количество точек: ");
        int numberOfPoints;
        while (!int.TryParse(Console.ReadLine(), out numberOfPoints) || numberOfPoints <= 0)
        {
            Console.Write("Пожалуйста, введите положительное целое число: ");
        }
        List<Point> points = new List<Point>();
        for (int i = 1; i <= numberOfPoints; i++)
        {
            Console.Write($"Введите координаты точки {i} (x y): ");
            string[] input = Console.ReadLine().Split();
            if (input.Length != 2 ||
                !double.TryParse(input[0], out double x) ||
                !double.TryParse(input[1], out double y))
            {
                Console.WriteLine("Некорректный ввод. Попробуйте еще раз.");
                i--;
                continue;
            }
            points.Add(new Point(i, x, y));
        }
        Point basePoint = points.OrderBy(p => p.Y).ThenBy(p => p.X).First();
        points = points.OrderBy(p => Math.Atan2(p.Y - basePoint.Y, p.X - basePoint.X)).ToList();
        Console.WriteLine("Отсортированные точки:");
        foreach (var point in points)
        {
            Console.WriteLine($"Точка {point.Index}: ({point.X}, {point.Y})");
        }
        double minDistance = double.MaxValue;
        int pointAIndex = -1;
        int pointBIndex = -1;
        for (int i = 0; i < points.Count; i++)
        {
            for (int j = i + 1; j < points.Count; j++)
            {
                double distance = points[i].DistanceTo(points[j]);
                if (distance < minDistance)
                {
                    minDistance = distance;
                    pointAIndex = points[i].Index;
                    pointBIndex = points[j].Index;
                }
            }
        }
        Console.WriteLine($"Сегмент наименьшей длины между точками {pointAIndex} и {pointBIndex} с длиной {minDistance}");
    }
}