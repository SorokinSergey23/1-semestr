﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace StarCatalog
{
    public class Star
    {
        public string Name { get; set; }
        public double ApparentMagnitude { get; set; }
        public double Distance { get; set; }
        public double RightAscension { get; set; }
        public double Declination { get; set; }
        public Star(string name, double apparentMagnitude, double distance, double rightAscension, double declination)
        {
            Name = name;
            ApparentMagnitude = apparentMagnitude;
            Distance = distance;
            RightAscension = rightAscension;
            Declination = declination;
        }
        public override string ToString()
        {
            return $"Имя: {Name}, Видимая величина: {ApparentMagnitude}, Расстояние: {Distance} световых лет, " +
                   $"Координаты: ({RightAscension}, {Declination})";
        }
    }
    public class StarCatalog
    {
        private List<Star> stars;
        public StarCatalog()
        {
            stars = new List<Star>();
        }
        public void AddStar(Star star)
        {
            stars.Add(star);
        }
        public void SortByDistance()
        {
            stars = stars.OrderBy(star => star.Distance).ToList();
        }
        public List<Star> FindByApparentMagnitude(double magnitude)
        {
            return stars.Where(star => star.ApparentMagnitude <= magnitude).ToList();
        }
        public void DisplayStars()
        {
            foreach (var star in stars)
            {
                Console.WriteLine(star);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            StarCatalog catalog = new StarCatalog();
            catalog.AddStar(new Star("Сириус", -1.46, 8.6, 6.752, -16.716));
            catalog.AddStar(new Star("Канопус", -0.72, 310, 6.399, -52.694));
            catalog.AddStar(new Star("Арктур", -0.05, 36.7, 14.261, 19.182));
            catalog.AddStar(new Star("Альфа Центавра", -0.27, 4.37, 14.660, -60.835));
            Console.WriteLine("Список звезд до сортировки:");
            catalog.DisplayStars();
            catalog.SortByDistance();
            Console.WriteLine("\nСписок звезд после сортировки по расстоянию:");
            catalog.DisplayStars();
            Console.Write("\nВведите максимальную видимую величину для поиска: ");
            double magnitude = Convert.ToDouble(Console.ReadLine());
            var foundStars = catalog.FindByApparentMagnitude(magnitude);
            Console.WriteLine($"\nЗвезды с видимой величиной меньше или равной {magnitude}:");
            foreach (var star in foundStars)
            {
                Console.WriteLine(star);
            }
            Console.ReadKey();
        }
    }
}