﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form2 f22;
        private int result = 0; 
        private int result1 = 1;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            int threshold = int.Parse(f22.textBox12.Text); 
            int[] numbers = Array.ConvertAll(textBox13.Text.Split(';'), int.Parse); 
            bool hasValidNumbers = false; 

            if (f22.radioButton1.Checked)
            {
                foreach (var number in numbers)
                {
                    if (number > threshold)
                    {
                        result += number;
                        result1 *= number;
                        hasValidNumbers = true; 
                    }
                }
            }
            else if (f22.radioButton2.Checked)
            {
                foreach (var number in numbers)
                {
                    if (number < threshold)
                    {
                        result += number;
                        result1 *= number;
                        hasValidNumbers = true; 
                    }
                }
            }
            if (!hasValidNumbers)
            {
                string lol = "Лишняя хромосома?";
                if (f22.checkBox1.Checked)
                {
                    textBox1.Text = lol;
                }
                if (f22.checkBox2.Checked)
                {
                    textBox2.Text = lol;
                }
            }
            else
            {
                if (f22.checkBox1.Checked)
                {
                    textBox1.Text = result.ToString();
                }
                if (f22.checkBox2.Checked)
                {
                    textBox2.Text = result1.ToString();
                }
            }
        }
        private void label4_Click(object sender, EventArgs e)
        {
            if (f22.checkBox1.Checked)
            {
                textBox1.Text = result.ToString();
            }
            if (f22.checkBox2.Checked)
            {
                textBox2.Text = result1.ToString();
            }
        }
        private void label5_Click(object sender, EventArgs e)
        {
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
