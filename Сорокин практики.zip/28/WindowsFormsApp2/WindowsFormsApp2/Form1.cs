﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public static int rgi; // для хранения номера выбранной радиокнопки
        public static bool b1, b2; // для кнопок выбора
        public static string s1; // для строки редактирования
        private Form4 единственнаяФорма = null;
        public Form1()
        {
            InitializeComponent();
        }

            private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void создатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 f3;
            f3 = new Form3();
            f3.MdiParent = this;
            f3.label1.Text = s1;
            f3.Show();
        }

        private void закрытьТекущиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild != null)
            {
                this.ActiveMdiChild.Close();
            }
        }

        private void закрытьВсеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in this.MdiChildren)
            {
                childForm.Close();
            }
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            switch (rgi)
            {
                case 0:
                    f2.rB1.Checked = true;
                    break;
                case 1:
                    f2.rB2.Checked = true;
                    break;
            }
            f2.cB1.Checked = b1;
            f2.cB2.Checked = b2;
            f2.tB1.Text = s1;
            f2.ShowDialog();
        }

        private void единственнаяФормаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (единственнаяФорма == null || единственнаяФорма.IsDisposed)
            {
                единственнаяФорма = new Form4();
                единственнаяФорма.MdiParent = this;
                единственнаяФорма.label2.Text = s1;
                единственнаяФорма.Show();
            }
            else
            {
                единственнаяФорма.Activate();
            }
        }

        private void каскадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void мозаикаГоризонтальноToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void мозаикаВертикальноToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 ab1 = new AboutBox1();
            ab1.ShowDialog();
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rgi = 0;
            b1 = false;
            b2 = true;
            s1 = "I love Rei";
        }
    }
}
