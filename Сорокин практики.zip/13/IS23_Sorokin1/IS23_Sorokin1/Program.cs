﻿using System;
class Program
{
    static void Main(string[] args)
    {
        int[] numbers = { 15, 22, 37, 45, 58, 63, 72, 81, 96 };
        Console.WriteLine("Элементы массива, которые больше 20 и меньше 50");
        foreach (int number in numbers)
         {
        if (number > 20 && number < 50)
         {
          Console.WriteLine(number);
         }
        }
    }
}