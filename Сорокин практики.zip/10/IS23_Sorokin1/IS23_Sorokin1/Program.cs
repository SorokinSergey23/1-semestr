﻿using System;
class Program
{
    static void Main(string[] args)
    {
        int num, min = int.MaxValue;
        Console.WriteLine("Введите цифры (0 для остановки)");
        do
        {
            Console.Write("Ввидите число: ");
            num = Convert.ToInt32(Console.ReadLine());

            if (num < min && num != 0)
            {
                min = num;
            }
        } 
        while (num != 0);
        Console.WriteLine("Минимальное количество: " + min);
    }

}