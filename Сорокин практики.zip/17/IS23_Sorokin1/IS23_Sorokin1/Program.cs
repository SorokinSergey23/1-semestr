﻿using System;
using System.IO;
class Program
{
    static void Main(string[] args)
    {
        string numbers = string.Empty;
        for (int i = 1; i <= 500; i++)
        {
            numbers += i.ToString() + ",";
        }
        numbers = numbers.TrimEnd(',');
        File.WriteAllText("C:\\Users\\Student28\\Desktop\\ПЗ_17 Сорокин\\IS23_Sorokin1\\numbers.txt", numbers);
    }
}
