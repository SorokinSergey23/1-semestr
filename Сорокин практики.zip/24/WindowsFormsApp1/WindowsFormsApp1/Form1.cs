﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace ColorAndSizeManager
{
    public partial class Form1 : Form
    {
        private bool allowColorChange = false;
        private bool isSizeChangeAllowed = false;
        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndexChanged += ComboBox1_SelectedIndexChanged;
            this.BackColor = Color.White;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
            private void button1_Click(object sender, EventArgs e)
        {
            isSizeChangeAllowed = !isSizeChangeAllowed;
            this.FormBorderStyle = isSizeChangeAllowed ? FormBorderStyle.Sizable : FormBorderStyle.FixedSingle;
            allowColorChange = !allowColorChange; 
            button1.Text = allowColorChange ? "Изменение цвета формы запретить!" : "Изменение цвета формы разрешить!";
        }
        private void button2_Click(object sender, EventArgs e)
        {
            
        }
        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (allowColorChange)
            {
                switch (comboBox1.SelectedItem.ToString())
                {
                    case "Red":
                        this.BackColor = Color.Red;
                        break;
                    case "Green":
                        this.BackColor = Color.Green;
                        break;
                    case "Blue":
                        this.BackColor = Color.Blue;
                        break;
                    case "Yellow":
                        this.BackColor = Color.Yellow;
                        break;
                    default:
                        this.BackColor = Color.White;
                        break;
                }
            }
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            if (allowColorChange)
            {
                this.BackColor = Color.Yellow;
            }
        }
    }
}
