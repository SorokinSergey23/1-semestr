﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Введите число в восьмеричной системе счисления:");
        string octalInput = Console.ReadLine();
        ulong decimalValue = Convert.ToUInt64(octalInput, 8);
        Console.WriteLine($"Десятичное представление: {decimalValue}");
    }
}
