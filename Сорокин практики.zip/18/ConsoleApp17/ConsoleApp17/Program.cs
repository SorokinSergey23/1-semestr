﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Введите целое число это будет меньшую диагональ ромба: ");
        int d1 = int.Parse(Console.ReadLine());
        int d2 = d1 * 2;
        int halfD1 = d1 / 2;
        int halfD2 = d2 / 2;
        for (int i = 0; i < halfD2; i++)
        {
            Console.Write(new string(' ', halfD2 - i));
            Console.WriteLine(new string('*', d1 + 2 * i));
        }
        for (int i = halfD2 - 1; i >= 0; i--)
        {
            Console.Write(new string(' ', halfD2 - i));
            Console.WriteLine(new string('*', d1 + 2 * i));
        }
    }
}