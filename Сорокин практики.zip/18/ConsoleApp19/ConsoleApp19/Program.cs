﻿using System;
using System.Collections.Generic;
class Program
{
    static void Main()
    {
        Console.Write("Введите количество цифр числа: ");
        int digits = int.Parse(Console.ReadLine());
        Console.Write("Введите сумму цифр числа: ");
        int sum = int.Parse(Console.ReadLine());
        List<int> results = new List<int>();
        FindNumbers(digits, sum, 0, 0, results);
        Console.WriteLine($"Найденные числа с {digits} цифрами и суммой {sum}:");
        foreach (var number in results)
        {
            Console.WriteLine(number);
        }
    }
    static void FindNumbers(int digits, int sum, int currentNumber, int currentDigitCount, List<int> results)
    {
        if (currentDigitCount == digits)
        {
            if (sum == 0)
            {
                results.Add(currentNumber);
            }
            return;
        }
        int start = (currentDigitCount == 0) ? 1 : 0; 
        int end = 9;
        for (int digit = start; digit <= end; digit++)
        {
            if (digit <= sum)
            {
                FindNumbers(digits, sum - digit, currentNumber * 10 + digit, currentDigitCount + 1, results);
            }
        }
    }
}
