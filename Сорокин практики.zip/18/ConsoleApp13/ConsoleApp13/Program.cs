﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение A: ");
        double A = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите значение J: ");
        double tau = Convert.ToDouble(Console.ReadLine());
        double xStart = 0;
        double xEnd = 10; 
        double step = 0.5; 
        for (double x = xStart; x <= xEnd; x += step)
        {
            double y = A * Math.Exp(-x / tau);
        }
        Console.WriteLine("\nГрафик:");
        for (double x = xStart; x <= xEnd; x += step)
        {
            double y = A * Math.Exp(-x / tau);
            int numberOfStars = (int)(y * 10); 
            Console.WriteLine(new string('*', numberOfStars));
        }
    }
}
