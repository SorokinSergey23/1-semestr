﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите число в диапазоне от 0 до 18446744073709551615: ");
        ulong number = ulong.Parse(Console.ReadLine());
        int countOfOnes = CountOnesInBinary(number);
        if (countOfOnes % 2 == 0)
        {
            Console.WriteLine("Количество единиц в двоичном представлении четное.");
        }
        else
        {
            Console.WriteLine("Количество единиц в двоичном представлении нечетное.");
        }
    }

    static int CountOnesInBinary(ulong number)
    {
        int count = 0;
        while (number > 0)
        {
            count += (int)(number & 1);
            number >>= 1;
        }
        return count;
    }
}
