﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите значение A: ");
        double A = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите значение w: ");
        double omega = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите значение a: ");
        double alpha = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите количество итераций: ");
        int iterations = Convert.ToInt32(Console.ReadLine());
        double T = Math.PI / omega; 
        double maxY = A; 
        double rectangleArea = T * maxY;
        int pointsUnderCurve = 0;
        Random rand = new Random();
        for (int i = 0; i < iterations; i++)
        {
            double x = rand.NextDouble() * T;
            double y = rand.NextDouble() * maxY;
            if (y < A * Math.Sin(omega * x + alpha))
            {
                pointsUnderCurve++;
            }
        }
        double areaUnderCurve = rectangleArea * ((double)pointsUnderCurve / iterations);
        Console.WriteLine($"Площадь фигуры, ограниченной осями координат и первым полупериодом функции: {areaUnderCurve}");
    }
}
