﻿using System;
namespace Ser5
{
    class Program
    {
        static void Main(string[] args)
        {
            double x = 2;
            double y = 5;
            double nX = -x;
            double nY = -y;
            double nXY = -x * -y;
            double otvet = nX - nY / (1 + nXY);
            Console.WriteLine($"Ответ {otvet}");
            Console.ReadKey();
        }
    }
}