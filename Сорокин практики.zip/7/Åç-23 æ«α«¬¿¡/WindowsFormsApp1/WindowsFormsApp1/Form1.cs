﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) ||
          string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text) ||
          string.IsNullOrEmpty(textBox5.Text) || string.IsNullOrEmpty(textBox6.Text) ||
          string.IsNullOrEmpty(numericUpDown1.Text))
            {
                lblError.Text = "Не все данные введены!";
            }
            else
            {
                string gender = "";
            if (radioButton1.Checked)
            {
                gender = "Мужской";
            }
            else if (radioButton2.Checked)
            {
                gender = "Женский";
            }
            string filePath = @"C:\Users\Student28\Desktop\Новая папка\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\Страхователи.txt"; 
            using (StreamWriter sw = File.AppendText (filePath))
            try
            {
                        sw.WriteLine($"Фамилия " + textBox1.Text);
                        sw.WriteLine($"Имя " + textBox2.Text);
                        sw.WriteLine($"Город " + textBox3.Text);
                        sw.WriteLine($"Улица " + textBox4.Text);
                        sw.WriteLine($"Дом " + textBox5.Text);
                        sw.WriteLine($"Кв " + textBox6.Text);
                        sw.WriteLine($"Пол:" + gender);
                        sw.WriteLine($"Срок страхования:" + numericUpDown1.Value.ToString());
                        sw.WriteLine($"Вид страхования:" + comboBox1.SelectedItem.ToString());
                    
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }
            MessageBox.Show("Данное успешно сохранены в файлы!");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
