﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RectangleSorting
{
    class Rectangle
    {
        public double Width { get; }
        public double Height { get; }

        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }

        public double Area()
        {
            return Width * Height;
        }

        public string Orientation()
        {
            return Width > Height ? "Горизонтальный" : "Вертикальный";
        }

        public override string ToString()
        {
            return $"Ширина: {Width}, Высота: {Height}, Площадь: {Area()}, Ориентация: {Orientation()}";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Rectangle> rectangles = new List<Rectangle>();
            Console.Write("Введите количество прямоугольников (максимум 25): ");
            int count = int.Parse(Console.ReadLine());

            // Проверка на превышение лимита
            if (count > 25)
            {
                Console.WriteLine("Вы не можете ввести больше 25 прямоугольников.");
                return; // Завершение работы программы
            }

            for (int i = 0; i < count; i++)
            {
                Console.Write($"Введите ширину прямоугольника {i + 1}: ");
                double width = double.Parse(Console.ReadLine());

                Console.Write($"Введите высоту прямоугольника {i + 1}: ");
                double height = double.Parse(Console.ReadLine());

                rectangles.Add(new Rectangle(width, height));
            }

            // Сортировка по площади
            var sortedRectangles = rectangles.OrderBy(r => r.Area()).ToList();

            // Вывод результатов
            Console.WriteLine("\nСортировка прямоугольников по площади:");
            foreach (var rectangle in sortedRectangles)
            {
                Console.WriteLine(rectangle);
            }

            Console.ReadKey();
        }
    }
}
