﻿using System;
using System.Collections.Generic;
using System.Linq;
public class Triangle
{
    public double SideA { get; }
    public double SideB { get; }
    public double SideC { get; }
    public Triangle(double sideA, double sideB, double sideC)
    {
        SideA = sideA;
        SideB = sideB;
        SideC = sideC;
    }
    public double Area()
    {
        double semiPerimeter = (SideA + SideB + SideC) / 2;
        return Math.Sqrt(semiPerimeter * (semiPerimeter - SideA) * (semiPerimeter - SideB) * (semiPerimeter - SideC));
    }
    public bool IsSimilar(Triangle other)
    {
        double[] sides1 = { SideA, SideB, SideC };
        double[] sides2 = { other.SideA, other.SideB, other.SideC };
        Array.Sort(sides1);
        Array.Sort(sides2);
        return Math.Abs(sides1[0] / sides2[0] - sides1[1] / sides2[1]) < 1e-6 &&
               Math.Abs(sides1[1] / sides2[1] - sides1[2] / sides2[2]) < 1e-6;
    }
}
public class TriangleSorter
{
    public static Triangle[] SortByArea(Triangle[] triangles)
    {
        return triangles.OrderBy(t => t.Area()).ToArray();
    }
}
public class SimilarityGrouper
{
    public static List<List<Triangle>> GroupSimilarTriangles(Triangle[] triangles)
    {
        var groups = new List<List<Triangle>>();
        foreach (var triangle in triangles)
        {
            bool foundGroup = false;
            foreach (var group in groups)
            {
                if (triangle.IsSimilar(group[0]))
                {
                    group.Add(triangle);
                    foundGroup = true;
                    break;
                }
            }
            if (!foundGroup)
            {
                groups.Add(new List<Triangle> { triangle });
            }
        }
        return groups;
    }
}
class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите количество треугольников: ");
        int numberOfTriangles = int.Parse(Console.ReadLine());
        Triangle[] triangles = new Triangle[numberOfTriangles];
        for (int i = 0; i < numberOfTriangles; i++)
        {
            Console.WriteLine($"Введите длины сторон треугольника {i + 1} (через пробел):");
            string[] sides = Console.ReadLine().Split(' ');
            double sideA = double.Parse(sides[0]);
            double sideB = double.Parse(sides[1]);
            double sideC = double.Parse(sides[2]);
            triangles[i] = new Triangle(sideA, sideB, sideC);
        }
        var sortedTriangles = TriangleSorter.SortByArea(triangles);
        Console.WriteLine("\nТреугольники, отсортированные по площади:");
        foreach (var triangle in sortedTriangles)
        {
            Console.WriteLine($"Треугольник со сторонами {triangle.SideA}, {triangle.SideB}, {triangle.SideC} имеет площадь {triangle.Area()}");
        }
        var similarGroups = SimilarityGrouper.GroupSimilarTriangles(triangles);
        Console.WriteLine("\nГруппы подобных треугольников:");
        foreach (var group in similarGroups)
        {
            Console.WriteLine("Группа:");
            foreach (var triangle in group)
            {
                Console.WriteLine($"Треугольник со сторонами {triangle.SideA}, {triangle.SideB}, {triangle.SideC}");
            }
        }
    }
}
