﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Введите целое число (диаметр окружности): ");
        int diameter;
        int.TryParse(Console.ReadLine(), out diameter);
        if (diameter <= 0)
        {
            Console.WriteLine("Пожалуйста введите положительное целое число.");
            return;
        }
        int radius = diameter / 2;
        DrawCircle(radius);
    }
    static void DrawCircle(int radius)
    {
        int height = radius * 2;
        int width = radius * 2;
        for (int y = 0; y <= height; y++)
        {
            for (int x = 0; x <= width; x++)
            {
                double distance = Math.Sqrt(Math.Pow(x - radius, 2) + Math.Pow(y - radius, 2));
                if (distance >= radius - 0.5 && distance <= radius + 0.5)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(" ");
                }
            }
            Console.WriteLine();
        }
    }
}