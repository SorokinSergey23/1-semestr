﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Введите радиус сферы: ");
        double radius = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите количество итераций: ");
        int iterations = Convert.ToInt32(Console.ReadLine());
        double volume = MonteCarloSphereVolume(radius, iterations);
        double exactVolume = (4.0 / 3.0) * Math.PI * Math.Pow(radius, 3);
        Console.WriteLine($"Приблизительный объем сферы: {volume}");
        Console.WriteLine($"Точный объем сферы: {exactVolume}");
        Console.WriteLine($"Точность: {Math.Abs(volume - exactVolume) / exactVolume * 100}%");
    }
    static double MonteCarloSphereVolume(double radius, int iterations)
    {
        Random random = new Random();
        int insideSphereCount = 0;
        for (int i = 0; i < iterations; i++)
        {
            double x = (random.NextDouble() * 2 - 1) * radius;
            double y = (random.NextDouble() * 2 - 1) * radius;
            double z = (random.NextDouble() * 2 - 1) * radius;
            if (x * x + y * y + z * z <= radius * radius)
            {
                insideSphereCount++;
            }
        }
        double cubeVolume = Math.Pow(radius * 2, 3);
        return (insideSphereCount / (double)iterations) * cubeVolume;
    }
}