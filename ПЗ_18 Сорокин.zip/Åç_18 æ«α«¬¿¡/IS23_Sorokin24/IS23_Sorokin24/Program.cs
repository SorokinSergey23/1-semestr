﻿using System;
class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите положительное целое число X: ");
        int X = int.Parse(Console.ReadLine());
        Console.Write("Введите положительное целое число Y: ");
        int Y = int.Parse(Console.ReadLine());
        if (X <= 0 || Y <= 0)
        {
            Console.WriteLine("Оба числа должны быть положительными.");
            return;
        }
        ulong result = Power(X, Y);
        Console.WriteLine($"Результат {X}^{Y} = {result}");
    }
    static ulong Power(int x, int y)
    {
        if (y == 0)
        {
            return 1;
        }
        ulong result = 0;
        for (int i = 0; i < x; i++)
        {
            result = Add(result, Power(x, y - 1));
        }
        return result;
    }
    static ulong Add(ulong a, ulong b)
    {
        while (b != 0)
        {
            ulong carry = a & b;
            a = a ^ b;
            b = carry << 1;
        }
        return a;
    }
}
