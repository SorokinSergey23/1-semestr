﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Введите количество цифр в номере билета (четное число): ");
        int numberOfDigits = int.Parse(Console.ReadLine());
        int halfDigits = numberOfDigits / 2;
        int maxSum = 9 * halfDigits;
        int[] count = new int[maxSum + 1];
        for (int i = 0; i < Math.Pow(10, halfDigits); i++)
        {
            int sum = 0;
            int temp = i;

            for (int j = 0; j < halfDigits; j++)
            {
                sum += temp % 10;
                temp /= 10;
            }

            count[sum]++;
        }
        long luckyTickets = 0;
        for (int i = 0; i <= maxSum; i++)
        {
            luckyTickets += (long)count[i] * count[i];
        }
        Console.WriteLine($"Количество 'счастливых' билетов с {numberOfDigits} цифрами: {luckyTickets}");
    }
}
