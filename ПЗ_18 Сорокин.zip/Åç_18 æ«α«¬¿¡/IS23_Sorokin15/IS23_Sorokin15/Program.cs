﻿using System;
class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите радиус окружности: ");
        double radius = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите желаемую точность: ");
        double precision = Convert.ToDouble(Console.ReadLine());
        double area = CalculateCircleArea(radius, precision);
        Console.WriteLine($"Приближенная площадь окружности с радиусом {radius} равна: {area}");
    }
    static double CalculateCircleArea(double radius, double precision)
    {
        Random random = new Random();
        long insideCircle = 0;
        long totalPoints = 0;
        double estimatedArea = 0.0;
        double previousArea = 0.0;
        do
        {
            double x = (random.NextDouble() * 2 - 1) * radius;
            double y = (random.NextDouble() * 2 - 1) * radius;
            if (x * x + y * y <= radius * radius)
            {
                insideCircle++;
            }
            totalPoints++;
            estimatedArea = (double)insideCircle / totalPoints * (4 * radius * radius);
            if (totalPoints > 1)
            {
                double areaDifference = Math.Abs(estimatedArea - previousArea);
                if (areaDifference < precision)
                {
                    break;
                }
            }
            previousArea = estimatedArea;
        } while (true);
        return estimatedArea;
    }
}