﻿using System;
class Program
{
    static void Main()
    {
        double a, b, h;
        Console.Write("Введите начало интервала: ");
        a = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите конец интервала: ");
        b = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите шаг: ");
        h = Convert.ToDouble(Console.ReadLine());
        double area = CalculateArea(a, b, h);
        Console.WriteLine($"Площадь под кривой на интервале [{a}, {b}] с шагом {h}: {area}");
    }
    static double CalculateArea(double a, double b, double h)
    {
        double area = 0.0;
        double x = a;
        while (x < b)
        {
            double y1 = Function(x);
            double y2 = Function(x + h);
            area += (y1 + y2) * h / 2;
            x += h;
        }
        if (x > b)
        {
            double y1 = Function(b - h);
            double y2 = Function(b);
            area -= (y1 + y2) * (x - b) / 2;
        }
        return area;
    }
    static double Function(double x)
    {
        return 3 * x * x - 2 * x + 5;
    }
}