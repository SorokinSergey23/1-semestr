﻿using System;
class Program
{
    static void Main()
    {
        double a, b, step;
        Console.Write("Введите начало интервала:");
        a = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите конец интервала:");
        b = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите шаг изменения аргумента:");
        step = Convert.ToDouble(Console.ReadLine());
        double area = CalculateArea(a, b, step);
        Console.WriteLine($"Площадь под кривой y = 7 * sin(x) на интервале [{a}, {b}] равна: {area}");
    }
    static double CalculateArea(double a, double b, double step)
    {
        double area = 0.0;
        for (double x = a; x < b; x += step)
        {

            double y1 = 7 * Math.Sin(x);
            double y2 = 7 * Math.Sin(x + step);
            area += (y1 + y2) * step / 2;
        }
        return area;
    }
}