﻿using System;
using System.Collections.Generic;
class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите количество единичных разрядов: ");
        int countOnes = int.Parse(Console.ReadLine());
        const int totalBits = 64;
        if (countOnes < 0 || countOnes > totalBits)
        {
            Console.WriteLine("Количество единичных разрядов должно быть от 0 до 64.");
            return;
        }
        HashSet<ulong> results = new HashSet<ulong>();
        GenerateNumbers(results, 0, countOnes, totalBits);
        Console.WriteLine("Все возможные значения чисел:");
        foreach (var number in results)
        {
            Console.WriteLine(number);
        }
    }
    static void GenerateNumbers(HashSet<ulong> results, ulong current, int remainingOnes, int totalBits, int position = 0)
    {
        if (remainingOnes == 0)
        {
            results.Add(current);
            return;
        }
        for (int i = position; i <= totalBits - remainingOnes; i++)
        {
            ulong newNumber = current | (1UL << i);
            GenerateNumbers(results, newNumber, remainingOnes - 1, totalBits, i + 1);
        }
    }
}