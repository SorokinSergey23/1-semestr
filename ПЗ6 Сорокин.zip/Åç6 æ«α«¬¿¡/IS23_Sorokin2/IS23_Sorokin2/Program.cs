﻿using System;
class Program
{
    static void Main()
    {
        string lastName = "Сорокин";
        string birthDate = "04.10.2007";
        string birthPlace = "Фатеж";
        int age = 17; 
        Console.WriteLine($"Фамилия: {lastName}");
        Console.WriteLine($"Дата рождения: {birthDate}");
        Console.WriteLine($"Место рождения: {birthPlace}");
        Console.WriteLine($"Возраст: {age} лет"); 
    }
}